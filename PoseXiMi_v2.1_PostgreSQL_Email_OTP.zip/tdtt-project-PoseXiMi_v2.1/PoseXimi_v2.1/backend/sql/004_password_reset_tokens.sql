-- token_hash là HMAC-SHA256 của mã OTP email, không lưu mã gốc.
-- failed_attempts bổ sung để chặn brute-force xuyên các phiên server.
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  token_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  token_hash VARCHAR(255) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  failed_attempts INT NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0)
);

CREATE INDEX IF NOT EXISTS ix_password_reset_tokens_user_created
  ON password_reset_tokens (user_id, created_at DESC);
