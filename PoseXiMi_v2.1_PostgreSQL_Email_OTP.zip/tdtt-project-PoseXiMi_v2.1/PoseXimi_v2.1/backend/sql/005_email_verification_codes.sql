-- Bảng bổ sung vì sơ đồ gốc chưa có dữ liệu cho xác thực email.
CREATE TABLE IF NOT EXISTS email_verification_codes (
  code_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  code_hash VARCHAR(255) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  failed_attempts INT NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0)
);

CREATE INDEX IF NOT EXISTS ix_email_verification_codes_user_created
  ON email_verification_codes (user_id, created_at DESC);
