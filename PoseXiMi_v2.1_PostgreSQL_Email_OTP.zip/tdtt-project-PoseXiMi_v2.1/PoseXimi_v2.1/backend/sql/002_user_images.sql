-- Metadata ảnh: file ảnh thật nằm trong kho lưu trữ, không nằm trong bảng.
CREATE TABLE IF NOT EXISTS user_images (
  image_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  file_name VARCHAR(255) NOT NULL,
  storage_key TEXT NOT NULL,
  mime_type VARCHAR(50) NOT NULL,
  file_size_bytes BIGINT NOT NULL CHECK (file_size_bytes >= 0),
  width INT CHECK (width > 0),
  height INT CHECK (height > 0),
  alt_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_user_images_user_created
  ON user_images (user_id, created_at DESC);
