import {
  normalizeEmail, validEmail, validUsername, validPassword, validCode,
  hashPassword, verifyPassword, newCode, codeHash, sameHash,
  newSessionToken, hashSessionToken,
} from "./security.mjs";

const COOKIE = "poseximi_session";
const SESSION_AGE = 7 * 86400;
const CODE_TTL_MS = 10 * 60_000;
const COOLDOWN_MS = 60_000;
const MAX_CODES_PER_HOUR = 5;
const MAX_WRONG_CODES = 5;

class ApiError extends Error {
  constructor(status, message, code, extra = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

function response(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(JSON.stringify(data));
}

function cookie(req, name) {
  return (req.headers.cookie || "").split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${name}=`))
    ?.slice(name.length + 1);
}

function sessionCookie(res, value, expire = false) {
  const secure = process.env.APP_ORIGIN?.startsWith("https://") ||
    process.env.TRUST_HTTPS === "1" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `${COOKIE}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${expire ? 0 : SESSION_AGE}${secure}`);
}

function publicUser(row) {
  return { id: row.user_id, email: row.email, username: row.username, isVerified: row.is_verified };
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16384) throw new ApiError(413, "Dữ liệu yêu cầu quá lớn.");
    chunks.push(chunk);
  }
  let body;
  try {
    body = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    throw new ApiError(400, "JSON không hợp lệ.");
  }
  if (!body || typeof body !== "object" || Array.isArray(body))
    throw new ApiError(400, "Dữ liệu JSON phải là object.");
  return body;
}

async function transaction(pool, operation) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await operation(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

/** Issue a one-time 6-digit email code. Transaction serializes issuance per user. */
async function issueCode(pool, mail, secret, user, purpose, now) {
  const table = purpose === "verify" ? "email_verification_codes" : "password_reset_tokens";
  const column = purpose === "verify" ? "code_hash" : "token_hash";
  const code = newCode();
  const hash = codeHash(secret, user.user_id, purpose, code);
  await transaction(pool, async (db) => {
    await db.query("SELECT user_id FROM users WHERE user_id = $1 FOR UPDATE", [user.user_id]);
    const last = await db.query(
      `SELECT created_at FROM ${table} WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [user.user_id],
    );
    if (last.rows[0] && now.getTime() - new Date(last.rows[0].created_at).getTime() < COOLDOWN_MS)
      throw new ApiError(429, "Hãy đợi 60 giây trước khi yêu cầu mã mới.", "CODE_COOLDOWN");
    const count = await db.query(
      `SELECT COUNT(*)::int AS total FROM ${table} WHERE user_id = $1 AND created_at > $2`,
      [user.user_id, new Date(now.getTime() - 3600000)],
    );
    if (Number(count.rows[0].total) >= MAX_CODES_PER_HOUR)
      throw new ApiError(429, "Bạn đã yêu cầu quá nhiều mã. Hãy thử lại sau.", "CODE_LIMIT");
    await db.query(`UPDATE ${table} SET used_at = $2 WHERE user_id = $1 AND used_at IS NULL`, [user.user_id, now]);
    await db.query(
      `INSERT INTO ${table} (user_id, ${column}, expires_at, created_at) VALUES ($1,$2,$3,$4)`,
      [user.user_id, hash, new Date(now.getTime() + CODE_TTL_MS), now],
    );
  });
  const subject = purpose === "verify" ? "PoseXimi - Xác nhận email" : "PoseXimi - Đặt lại mật khẩu";
  const action = purpose === "verify" ? "xác nhận địa chỉ email" : "đặt lại mật khẩu";
  try {
    await mail({
      to: user.email,
      subject,
      text: `Mã ${action} PoseXimi của bạn: ${code}\n\nMã có hiệu lực 10 phút và chỉ được dùng một lần. Nếu bạn không yêu cầu, hãy bỏ qua email này. Không cung cấp mã cho người khác.`,
    });
  } catch (error) {
    // Invalidate a code that was never successfully submitted to SMTP.
    await pool.query(`UPDATE ${table} SET used_at = NOW() WHERE user_id = $1 AND ${column} = $2 AND used_at IS NULL`, [user.user_id, hash]);
    console.error("SMTP delivery failed:", error.message);
    throw new ApiError(503, "Không thể gửi email lúc này. Kiểm tra cấu hình SMTP và thử lại sau 60 giây.", "EMAIL_DELIVERY_FAILED", { email: user.email });
  }
}

/** Returns a boolean. Invalid attempts are committed, never rolled back. */
async function consumeCode(db, userId, table, column, purpose, inputCode, secret, now) {
  const found = await db.query(
    `SELECT * FROM ${table} WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,
    [userId],
  );
  const row = found.rows[0];
  if (!row || row.used_at || new Date(row.expires_at).getTime() <= now.getTime() ||
      row.failed_attempts >= MAX_WRONG_CODES) return false;
  const expected = codeHash(secret, userId, purpose, inputCode);
  if (!sameHash(row[column], expected)) {
    await db.query(
      `UPDATE ${table} SET failed_attempts=failed_attempts+1, used_at=CASE WHEN failed_attempts+1 >= $2 THEN $3 ELSE used_at END WHERE ${purpose === "verify" ? "code_id" : "token_id"}=$1`,
      [purpose === "verify" ? row.code_id : row.token_id, MAX_WRONG_CODES, now],
    );
    return false;
  }
  await db.query(
    `UPDATE ${table} SET used_at=$2 WHERE ${purpose === "verify" ? "code_id" : "token_id"}=$1`,
    [purpose === "verify" ? row.code_id : row.token_id, now],
  );
  return true;
}

function originAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const expected = process.env.APP_ORIGIN
      ? new URL(process.env.APP_ORIGIN).origin
      : new URL(`http://${req.headers.host}`).origin;
    return new URL(origin).origin === expected;
  } catch { return false; }
}

export function createAuthHandler({ pool, mail, secret, now = () => new Date() }) {
  if (typeof secret !== "string" || secret.length < 32)
    throw new Error("OTP_SECRET không hợp lệ.");
  const limits = new Map();
  function throttle(req, action) {
    const key = `${req.socket.remoteAddress || "unknown"}:${action}`;
    const limit = action === "login" ? 10 : 20;
    const moment = now().getTime();
    let state = limits.get(key);
    if (!state || moment >= state.until) state = { hits: 0, until: moment + 15 * 60000 };
    state.hits++;
    limits.set(key, state);
    if (limits.size > 10000) limits.clear();
    if (state.hits > limit) throw new ApiError(429, "Thử quá nhiều lần. Hãy đợi 15 phút.");
  }

  async function run(req, res, action) {
    if (action === "me" && req.method === "GET") {
      const value = cookie(req, COOKIE);
      if (!value || value.length > 200) throw new ApiError(401, "Chưa đăng nhập.");
      const result = await pool.query(
        `SELECT u.user_id, u.email, u.username, u.is_verified FROM user_sessions s
         JOIN users u ON u.user_id=s.user_id
         WHERE s.refresh_token_hash=$1 AND s.expires_at>NOW() AND u.is_verified=TRUE`,
        [hashSessionToken(value)],
      );
      if (!result.rows.length) throw new ApiError(401, "Phiên đăng nhập đã hết hạn.");
      return response(res, 200, { user: publicUser(result.rows[0]) });
    }
    if (req.method !== "POST") throw new ApiError(405, "Phương thức không được hỗ trợ.");
    if (!originAllowed(req)) throw new ApiError(403, "Origin không hợp lệ.");
    if (!/application\/json/i.test(req.headers["content-type"] || ""))
      throw new ApiError(415, "API chỉ chấp nhận JSON.");
    throttle(req, action);
    const body = await readJson(req);

    if (action === "register") {
      const username = String(body.username || "").trim();
      const email = normalizeEmail(body.email);
      if (!validUsername(username) || !validEmail(email) || !validPassword(body.password))
        throw new ApiError(400, "Tên đăng nhập, email hoặc mật khẩu không đáp ứng điều kiện đăng ký.");
      const hashed = await hashPassword(body.password);
      let inserted;
      try {
        inserted = await pool.query(
          `INSERT INTO users (email, username, password_hash)
           VALUES ($1,$2,$3) RETURNING user_id, email`, [email, username, hashed],
        );
      } catch (error) {
        if (error.code === "23505") throw new ApiError(409, "Email hoặc tên đăng nhập đã được sử dụng.");
        throw error;
      }
      await issueCode(pool, mail, secret, inserted.rows[0], "verify", now());
      return response(res, 201, { message: "Tài khoản đã được tạo. Hãy kiểm tra email và nhập mã xác nhận.", email });
    }

    if (action === "verify-email") {
      const email = normalizeEmail(body.email);
      if (!validEmail(email) || !validCode(body.code)) throw new ApiError(400, "Email hoặc mã 6 chữ số không hợp lệ.");
      const result = await transaction(pool, async (db) => {
        const users = await db.query("SELECT user_id, is_verified FROM users WHERE LOWER(email)=$1 FOR UPDATE", [email]);
        const user = users.rows[0];
        if (!user || user.is_verified) return false;
        const valid = await consumeCode(db, user.user_id, "email_verification_codes", "code_hash", "verify", String(body.code), secret, now());
        if (!valid) return false;
        await db.query("UPDATE users SET is_verified=TRUE WHERE user_id=$1", [user.user_id]);
        return true;
      });
      if (!result) throw new ApiError(400, "Mã không đúng, đã hết hạn hoặc đã dùng. Hãy yêu cầu mã mới.");
      return response(res, 200, { message: "Email đã xác nhận. Bạn có thể đăng nhập." });
    }

    if (action === "resend-verification") {
      const email = normalizeEmail(body.email);
      if (!validEmail(email)) throw new ApiError(400, "Email không hợp lệ.");
      const user = (await pool.query("SELECT user_id, email, is_verified FROM users WHERE LOWER(email)=$1", [email])).rows[0];
      if (user && !user.is_verified) {
        try { await issueCode(pool, mail, secret, user, "verify", now()); }
        catch (error) { if (!(error instanceof ApiError) || !["CODE_COOLDOWN", "CODE_LIMIT"].includes(error.code)) throw error; }
      }
      return response(res, 200, { message: "Nếu email đang chờ xác nhận và đủ điều kiện gửi lại, mã mới sẽ được gửi." });
    }

    if (action === "forgot-password") {
      const email = normalizeEmail(body.email);
      if (!validEmail(email)) throw new ApiError(400, "Email không hợp lệ.");
      const user = (await pool.query("SELECT user_id, email, is_verified FROM users WHERE LOWER(email)=$1", [email])).rows[0];
      if (user?.is_verified) {
        try { await issueCode(pool, mail, secret, user, "reset", now()); }
        catch (error) { if (!(error instanceof ApiError) || !["CODE_COOLDOWN", "CODE_LIMIT"].includes(error.code)) throw error; }
      }
      return response(res, 200, { message: "Nếu email đã đăng ký và được xác nhận, bạn sẽ nhận mã đặt lại mật khẩu." });
    }

    if (action === "reset-password") {
      const email = normalizeEmail(body.email);
      if (!validEmail(email) || !validCode(body.code) || !validPassword(body.newPassword))
        throw new ApiError(400, "Email, mã xác nhận hoặc mật khẩu mới không hợp lệ (ít nhất 8 ký tự và một chữ hoa).");
      const newHash = await hashPassword(body.newPassword);
      const result = await transaction(pool, async (db) => {
        const users = await db.query("SELECT user_id FROM users WHERE LOWER(email)=$1 AND is_verified=TRUE FOR UPDATE", [email]);
        const user = users.rows[0];
        if (!user) return false;
        const valid = await consumeCode(db, user.user_id, "password_reset_tokens", "token_hash", "reset", String(body.code), secret, now());
        if (!valid) return false;
        await db.query("UPDATE users SET password_hash=$2, failed_login_attempts=0 WHERE user_id=$1", [user.user_id, newHash]);
        await db.query("DELETE FROM user_sessions WHERE user_id=$1", [user.user_id]);
        return true;
      });
      if (!result) throw new ApiError(400, "Mã đặt lại mật khẩu không đúng, đã hết hạn hoặc đã dùng.");
      return response(res, 200, { message: "Mật khẩu đã thay đổi. Hãy đăng nhập lại." });
    }

    if (action === "login") {
      const identity = String(body.username || "").trim().toLowerCase();
      const password = String(body.password || "");
      if (!identity || !password || password.length > 128) throw new ApiError(400, "Nhập tên đăng nhập/email và mật khẩu.");
      const users = await pool.query(
        "SELECT * FROM users WHERE LOWER(email)=$1 OR LOWER(username)=$1 LIMIT 1", [identity],
      );
      const user = users.rows[0];
      const valid = await verifyPassword(password, user?.password_hash);
      if (!user || !valid) {
        if (user) await pool.query("UPDATE users SET failed_login_attempts=failed_login_attempts+1 WHERE user_id=$1", [user.user_id]);
        throw new ApiError(401, "Tên đăng nhập hoặc mật khẩu không chính xác.");
      }
      if (!user.is_verified) throw new ApiError(403, "Hãy xác nhận email trước khi đăng nhập.", "EMAIL_NOT_VERIFIED", { email: user.email });
      const token = newSessionToken();
      await pool.query(
        `INSERT INTO user_sessions (user_id,refresh_token_hash,user_agent,ip_address,expires_at)
         VALUES ($1,$2,$3,$4,$5)`,
        [user.user_id, hashSessionToken(token), String(req.headers["user-agent"] || "").slice(0, 2048) || null,
          (req.socket.remoteAddress || "").slice(0, 45) || null, new Date(now().getTime() + SESSION_AGE * 1000)],
      );
      await pool.query("UPDATE users SET last_login_at=NOW(), failed_login_attempts=0 WHERE user_id=$1", [user.user_id]);
      sessionCookie(res, token);
      return response(res, 200, { user: publicUser(user) });
    }

    if (action === "logout") {
      const token = cookie(req, COOKIE);
      if (token && token.length <= 200) await pool.query("DELETE FROM user_sessions WHERE refresh_token_hash=$1", [hashSessionToken(token)]);
      sessionCookie(res, "", true);
      return response(res, 200, { message: "Đã đăng xuất." });
    }
    throw new ApiError(404, "API không tồn tại.");
  }

  return async (req, res, path) => {
    try { await run(req, res, path.slice("/api/auth/".length)); }
    catch (error) {
      if (!(error instanceof ApiError)) console.error("Auth handler error:", error);
      if (!res.headersSent) response(res, error.status || 500, {
        message: error instanceof ApiError ? error.message : "Có lỗi máy chủ.",
        ...(error.code ? { code: error.code } : {}),
        ...(error.extra || {}),
      });
    }
  };
}
