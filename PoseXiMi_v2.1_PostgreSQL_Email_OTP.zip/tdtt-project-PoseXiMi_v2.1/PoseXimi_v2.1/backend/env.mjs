import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { loadEnvFile } from "node:process";

const path = fileURLToPath(new URL("../.env", import.meta.url));
if (existsSync(path)) loadEnvFile(path);

export function checkSecrets() {
  const secret = process.env.OTP_SECRET || "";
  if (secret.length < 32 || secret.startsWith("replace-with-")) {
    throw new Error("OTP_SECRET phải có ít nhất 32 ký tự ngẫu nhiên trong .env.");
  }
}

export const PORT = Number(process.env.PORT || 5500);
export const HOST = process.env.HOST || "127.0.0.1";
