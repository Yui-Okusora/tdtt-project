import "./env.mjs";

export async function createMailer() {
  const nodemailer = (await import("nodemailer")).default;
  let transporter;
  return async ({ to, subject, text }) => {
    const { SMTP_HOST, SMTP_USER, SMTP_PASS, MAIL_FROM } = process.env;
    if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !MAIL_FROM) {
      throw new Error("Chưa cấu hình SMTP_HOST, SMTP_USER, SMTP_PASS, MAIL_FROM.");
    }
    if (!transporter) {
      transporter = nodemailer.createTransport({
        host: SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 465),
        secure: process.env.SMTP_SECURE !== "false",
        auth: { user: SMTP_USER, pass: SMTP_PASS },
        connectionTimeout: 10000,
        socketTimeout: 10000,
      });
    }
    await transporter.sendMail({ from: MAIL_FROM, to, subject, text });
  };
}
