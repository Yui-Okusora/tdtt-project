import { createHash, createHmac, randomBytes, randomInt, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
const scrypt = promisify(scryptCallback);

export const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
export const validEmail = (email) =>
  email.length <= 255 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
export const validUsername = (name) => /^[\p{L}\p{N}_.-]{3,30}$/u.test(name);
export const validPassword = (password) =>
  typeof password === "string" &&
  password.length >= 8 && password.length <= 128 && /[A-Z]/.test(password);
export const validCode = (code) => /^\d{6}$/.test(String(code || ""));

export async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = (await scrypt(password, salt, 64)).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export async function verifyPassword(password, saved) {
  // Do the same expensive hash even when the user does not exist.
  const fallback = `scrypt$${"0".repeat(32)}$${"0".repeat(128)}`;
  const candidate = String(saved || fallback);
  const [algorithm, salt, hash] = candidate.split("$");
  if (algorithm !== "scrypt" || !/^[a-f\d]{32}$/.test(salt || "") ||
      !/^[a-f\d]{128}$/.test(hash || "")) return false;
  const actual = await scrypt(password, salt, 64);
  return timingSafeEqual(actual, Buffer.from(hash, "hex"));
}

export const newCode = () => String(randomInt(0, 1_000_000)).padStart(6, "0");
export const newSessionToken = () => randomBytes(32).toString("base64url");
export const hashSessionToken = (token) => createHash("sha256").update(token).digest("hex");
export function codeHash(secret, userId, purpose, code) {
  return createHmac("sha256", secret)
    .update(`${purpose}:${userId}:${code}`).digest("hex");
}
export function sameHash(a, b) {
  return /^[a-f\d]{64}$/.test(String(a || "")) &&
    /^[a-f\d]{64}$/.test(String(b || "")) &&
    timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
}
