import "./env.mjs";

export async function createPool() {
  const { Pool } = await import("pg");
  const pool = new Pool({
    ...(process.env.DATABASE_URL ? { connectionString: process.env.DATABASE_URL } : {}),
    ...(process.env.PGSSLMODE === "require"
      ? { ssl: { rejectUnauthorized: true } }
      : {}),
    max: 10,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
  });
  try {
    await pool.query("SELECT 1");
    return pool;
  } catch (error) {
    await pool.end();
    throw error;
  }
}
