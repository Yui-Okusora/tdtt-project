import { readdir, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { createPool } from "./pool.mjs";

const dir = fileURLToPath(new URL("./sql/", import.meta.url));
const pool = await createPool();
try {
  const files = (await readdir(dir)).filter((name) => /^\d+_.*\.sql$/.test(name)).sort();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const name of files) {
      await client.query(await readFile(join(dir, name), "utf8"));
      console.log(`Applied ${name}`);
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
} finally {
  await pool.end();
}
