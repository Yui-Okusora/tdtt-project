import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { createPool } from "./pool.mjs";
import { createMailer } from "./mailer.mjs";
import { createAuthHandler } from "./auth.mjs";
import { checkSecrets, HOST, PORT } from "./env.mjs";

const ROOT = fileURLToPath(new URL("../", import.meta.url));
const MIME = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".png": "image/png", ".svg": "image/svg+xml", ".webp": "image/webp",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".json": "application/json",
  ".webmanifest": "application/manifest+json", ".ico": "image/x-icon",
};

function errorResponse(res, status, message) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ message }));
}

async function serveFrontend(req, res, path) {
  if (req.method !== "GET" && req.method !== "HEAD")
    return errorResponse(res, 405, "Phương thức không hợp lệ.");
  let requested;
  try { requested = decodeURIComponent(path); }
  catch { return errorResponse(res, 400, "Đường dẫn không hợp lệ."); }
  const visible = requested === "/" || ["/index.html", "/sw.js", "/manifest.webmanifest"].includes(requested) ||
    ["/js/", "/css/", "/assets/"].some((prefix) => requested.startsWith(prefix));
  if (!visible || requested.includes("\\") || requested.split("/").some((part) => part.startsWith(".")))
    return errorResponse(res, 404, "Không tìm thấy tài nguyên.");
  const full = resolve(ROOT, `.${requested === "/" ? "/index.html" : requested}`);
  if (full !== resolve(ROOT, "index.html") && !full.startsWith(resolve(ROOT) + sep))
    return errorResponse(res, 403, "Không có quyền truy cập.");
  try {
    if (!(await stat(full)).isFile()) return errorResponse(res, 404, "Không tìm thấy file.");
    res.writeHead(200, {
      "Content-Type": MIME[extname(full)] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff", "Cache-Control": "no-cache",
    });
    res.end(req.method === "HEAD" ? undefined : await readFile(full));
  } catch (error) {
    if (error.code === "ENOENT") return errorResponse(res, 404, "Không tìm thấy file.");
    throw error;
  }
}

checkSecrets();
const pool = await createPool();
const mail = await createMailer();
const handleAuth = createAuthHandler({ pool, mail, secret: process.env.OTP_SECRET });
const server = http.createServer(async (req, res) => {
  let path;
  try { path = new URL(req.url || "/", "http://localhost").pathname; }
  catch { return errorResponse(res, 400, "URL không hợp lệ."); }
  if (path.startsWith("/api/auth/")) return handleAuth(req, res, path);
  if (path.startsWith("/api/")) return errorResponse(res, 404, "API không tồn tại.");
  try { return await serveFrontend(req, res, path); }
  catch (error) { console.error(error); return errorResponse(res, 500, "Có lỗi máy chủ."); }
});

server.listen(PORT, HOST, () => console.log(`PoseXimi: http://localhost:${PORT}`));
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.once(signal, () => server.close(() => pool.end().finally(() => process.exit(0))));
}
