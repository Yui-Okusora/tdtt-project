# PoseXimi — Backend PostgreSQL & xác nhận qua email

## 1. Có gì mới?

- Backend Node.js kết nối **PostgreSQL**; không còn dùng `.local-data/users.json` và session RAM.
- Đăng ký tạo tài khoản ở trạng thái `is_verified = false` và gửi **OTP 6 số** qua SMTP.
- Xác nhận email trước khi đăng nhập; có chức năng gửi lại mã.
- Quên mật khẩu: nhập email → nhận OTP → nhập OTP, mật khẩu mới → xác nhận.
- Đổi mật khẩu làm **thu hồi mọi phiên đăng nhập cũ**.
- Các mã chỉ còn hiệu lực **10 phút**, dùng **một lần**, tối đa **5 lần nhập sai**; giới hạn 60 giây giữa các lần gửi và tối đa 5 mã/giờ/tài khoản.
- Database lưu **HMAC của OTP**, không lưu mã thật; mật khẩu lưu hash `scrypt` cùng salt riêng; phiên đăng nhập lưu hash SHA-256 của cookie.

> Lưu ý: Sơ đồ v0.1 có 4 bảng; thêm bảng `email_verification_codes` và cột `failed_attempts` trong `password_reset_tokens` để thực hiện xác nhận mail an toàn. `user_images` hiện chỉ có schema, chưa có API tải/lưu ảnh vào cloud.

## 2. Cài PostgreSQL

Yêu cầu: **Node.js >= 20.12** và PostgreSQL >= 13.

Trong `psql` (với quyền tạo database):

```sql
CREATE DATABASE poseximi;
```

Đặt mật khẩu riêng cho tài khoản PostgreSQL; ở môi trường thật nên tạo user chỉ có quyền cần thiết, không dùng superuser.

Các file SQL độc lập và được chạy lần lượt theo tên:

| File | Nội dung |
| --- | --- |
| `backend/sql/001_users.sql` | Bảng `users` và unique index không phân biệt hoa/thường |
| `backend/sql/002_user_images.sql` | Bảng `user_images`, khóa ngoại và index |
| `backend/sql/003_user_sessions.sql` | Bảng `user_sessions`, index |
| `backend/sql/004_password_reset_tokens.sql` | Bảng `password_reset_tokens`, index |
| `backend/sql/005_email_verification_codes.sql` | Bảng mới cho OTP xác minh email |
| `backend/sql/006_updated_at.sql` | Trigger tự cập nhật `users.updated_at` |

Chạy **từ thư mục `PoseXimi_v2.1`**:

```bash
npm install
```

Sao chép `.env.example` thành `.env`, chỉnh cấu hình:

```dotenv
PORT=5500
DATABASE_URL=postgresql://postgres:YOUR_DB_PASSWORD@localhost:5432/poseximi
PGSSLMODE=disable
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-google-app-password
MAIL_FROM="PoseXimi <your-email@gmail.com>"
OTP_SECRET=PASTE_RANDOM_SECRET_AT_LEAST_32_CHARACTERS
```

`OTP_SECRET` phải là chuỗi ngẫu nhiên mạnh, bí mật, ổn định giữa các lần restart; ví dụ tạo bằng:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Với Gmail có bật **xác minh 2 bước**, dùng **App Password** cho `SMTP_PASS`, không phải mật khẩu đăng nhập Gmail. Email gửi đi cần cấu hình SMTP hoạt động và quyền gửi mail hợp lệ. Không đẩy `.env` lên GitHub; đã có `.gitignore`.

```bash
npm run db:migrate
npm start
```

Mở `http://localhost:5500`. Các lệnh `node server.mjs` và `npm start` đều chạy backend mới. **Không mở `index.html` bằng `file://` hoặc chỉ chạy Live Server** khi cần test email/PostgreSQL, vì chúng không khởi động API.

### Chạy SQL riêng (không dùng Node)

Mở `psql` sau khi tạo database và chạy lần lượt:

```sql
\i backend/sql/001_users.sql
\i backend/sql/002_user_images.sql
\i backend/sql/003_user_sessions.sql
\i backend/sql/004_password_reset_tokens.sql
\i backend/sql/005_email_verification_codes.sql
\i backend/sql/006_updated_at.sql
```

Các file sử dụng `CREATE TABLE IF NOT EXISTS` nên có thể chạy lại, nhưng **không tự chuyển dữ liệu** từ schema khác nếu bảng cũ đã tồn tại. Khi nâng cấp hệ thống thực tế cần migration ALTER TABLE phù hợp.

## 3. API đã bổ sung

Tất cả API POST nhận JSON, chạy cùng domain với PWA (`/api/auth/...`), không cần CORS.

| Method | Endpoint | JSON body | Kết quả |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | `username`, `email`, `password` | Tạo tài khoản chưa xác nhận, gửi mã |
| POST | `/api/auth/verify-email` | `email`, `code` | Đánh dấu `is_verified=true` |
| POST | `/api/auth/resend-verification` | `email` | Yêu cầu gửi mã mới |
| POST | `/api/auth/login` | `username` (hoặc email), `password` | Phiên cookie HttpOnly nếu email đã xác nhận |
| GET | `/api/auth/me` | Không có | Thông tin tài khoản từ session PostgreSQL |
| POST | `/api/auth/logout` | `{}` | Xóa session và cookie |
| POST | `/api/auth/forgot-password` | `email` | Gửi OTP đặt lại mật khẩu (nếu có tài khoản được xác nhận) |
| POST | `/api/auth/reset-password` | `email`, `code`, `newPassword` | Đổi mật khẩu, thu hồi session cũ |

Ví dụ xác nhận email:

```bash
curl -X POST http://localhost:5500/api/auth/verify-email \
  -H 'Content-Type: application/json' \
  -d '{"email":"ban@example.com","code":"123456"}'
```

Ví dụ thay mật khẩu:

```bash
curl -X POST http://localhost:5500/api/auth/reset-password \
  -H 'Content-Type: application/json' \
  -d '{"email":"ban@example.com","code":"123456","newPassword":"MyNewPassword1"}'
```

## 4. Demo trực tiếp

1. Tạo tài khoản bằng email thật. API gửi mã; app tự mở hộp thoại **Xác nhận email**.
2. Nhập mã từ email → nhận thông báo thành công → đăng nhập.
3. Đăng xuất → **Quên mật khẩu?** → nhập email.
4. Nhập mã vừa nhận, mật khẩu mới có >=8 ký tự và >=1 chữ in hoa → xác nhận → đăng nhập bằng mật khẩu mới.
5. Thử nhập sai mã 5 lần, dùng lại mã đã sử dụng, hoặc đợi 10 phút để demo nhánh báo lỗi.

**Quan trọng cho báo cáo:** Đây là luồng **gửi email thật qua SMTP**, không phải mock demo. Không có SMTP hoặc PostgreSQL khả dụng thì không thể chạy end-to-end; script test có dùng mailer và DB giả lập **chỉ để kiểm thử tự động**.

## 5. Kiểm thử

```bash
npm run test:auth
```

Kiểm thử này dùng database/mail giả lập trong bộ test để kiểm tra logic OTP, mật khẩu, khóa nhập sai, đăng nhập, và thu hồi phiên. Để xác nhận hệ thống hoạt động thực tế vẫn phải chạy với **PostgreSQL + SMTP thật**.

## 6. Lưu ý trước khi triển khai công khai

- Đặt `APP_ORIGIN=https://your-domain` và chạy HTTPS; backend tự đặt cookie `Secure` khi `APP_ORIGIN` dùng HTTPS. Nếu dùng reverse proxy HTTPS, đặt thêm `TRUST_HTTPS=1` nếu cần.
- Bổ sung rate-limiter dùng Redis/DB ở gateway khi chạy nhiều worker; rate-limit IP hiện nằm trong RAM từng tiến trình, còn giới hạn OTP theo tài khoản nằm trong PostgreSQL.
- Cấu hình TLS PostgreSQL phù hợp nhà cung cấp (`PGSSLMODE=require` khi cần, xác minh CA).
- Có thể lập lịch xóa các `user_sessions`, `password_reset_tokens`, `email_verification_codes` quá hạn để tránh tích lũy dữ liệu.
- Các tài khoản cũ trong `.local-data/users.json` **không được tự động nhập sang PostgreSQL**. Cần migration riêng nếu muốn giữ dữ liệu trước đó.
