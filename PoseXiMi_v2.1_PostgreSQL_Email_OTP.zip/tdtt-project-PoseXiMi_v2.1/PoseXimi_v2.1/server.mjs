// Entry point tương thích: `node server.mjs` vẫn chạy backend PostgreSQL mới.
import "./backend/server.mjs";
