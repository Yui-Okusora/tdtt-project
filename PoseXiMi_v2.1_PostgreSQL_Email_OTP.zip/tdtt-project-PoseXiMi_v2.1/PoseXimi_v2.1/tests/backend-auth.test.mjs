import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { randomUUID } from "node:crypto";
import { createAuthHandler } from "../backend/auth.mjs";
import {
  hashPassword, verifyPassword, newCode, codeHash, sameHash,
} from "../backend/security.mjs";

const SECRET = "this-is-a-long-secret-used-only-for-node-tests-2026";
const rows = (items = []) => ({ rows: items });

class MemoryPool {
  constructor() {
    this.users = [];
    this.sessions = [];
    this.email_verification_codes = [];
    this.password_reset_tokens = [];
  }
  async connect() { return { query: (...args) => this.query(...args), release() {} }; }
  async query(sql, p = []) {
    const statement = sql.trim().replace(/\s+/g, " ");
    if (/^(BEGIN|COMMIT|ROLLBACK)$/.test(statement)) return rows();
    if (statement.startsWith("INSERT INTO users")) {
      if (this.users.some((u) => u.email === p[0] || u.username?.toLowerCase() === p[1]?.toLowerCase())) {
        const err = new Error("duplicate"); err.code = "23505"; throw err;
      }
      const row = { user_id: randomUUID(), email: p[0], username: p[1], password_hash: p[2], is_verified: false, failed_login_attempts: 0 };
      this.users.push(row);
      return rows([row]);
    }
    if (statement.startsWith("SELECT user_id FROM users WHERE user_id"))
      return rows(this.users.filter((u) => u.user_id === p[0]));
    if (statement.startsWith("SELECT user_id, is_verified FROM users WHERE LOWER(email)"))
      return rows(this.users.filter((u) => u.email === p[0]));
    if (statement.startsWith("SELECT user_id FROM users WHERE LOWER(email)"))
      return rows(this.users.filter((u) => u.email === p[0] && u.is_verified));
    if (statement.startsWith("SELECT user_id, email, is_verified FROM users WHERE LOWER(email)"))
      return rows(this.users.filter((u) => u.email === p[0]));
    if (statement.startsWith("SELECT * FROM users WHERE LOWER(email)"))
      return rows(this.users.filter((u) => u.email === p[0] || u.username?.toLowerCase() === p[0]));
    if (statement.startsWith("UPDATE users SET is_verified")) {
      this.users.find((u) => u.user_id === p[0]).is_verified = true;
      return rows();
    }
    if (statement.startsWith("UPDATE users SET password_hash")) {
      const user = this.users.find((u) => u.user_id === p[0]);
      user.password_hash = p[1]; user.failed_login_attempts = 0;
      return rows();
    }
    if (statement.startsWith("UPDATE users SET last_login_at")) {
      this.users.find((u) => u.user_id === p[0]).failed_login_attempts = 0;
      return rows();
    }
    if (statement.startsWith("UPDATE users SET failed_login_attempts")) {
      this.users.find((u) => u.user_id === p[0]).failed_login_attempts++;
      return rows();
    }
    for (const table of ["email_verification_codes", "password_reset_tokens"]) {
      const collection = this[table];
      const column = table === "email_verification_codes" ? "code_hash" : "token_hash";
      const id = table === "email_verification_codes" ? "code_id" : "token_id";
      if (statement.startsWith(`SELECT created_at FROM ${table}`))
        return rows(collection.filter((r) => r.user_id === p[0]).sort((a, b) => b.created_at - a.created_at).slice(0, 1));
      if (statement.startsWith(`SELECT COUNT(*)::int AS total FROM ${table}`))
        return rows([{ total: collection.filter((r) => r.user_id === p[0] && r.created_at > p[1]).length }]);
      if (statement.startsWith(`INSERT INTO ${table}`)) {
        collection.push({ [id]: randomUUID(), user_id: p[0], [column]: p[1], expires_at: p[2], created_at: p[3], used_at: null, failed_attempts: 0 });
        return rows();
      }
      if (statement.startsWith(`SELECT * FROM ${table}`))
        return rows(collection.filter((r) => r.user_id === p[0]).sort((a, b) => b.created_at - a.created_at).slice(0, 1));
      if (statement.startsWith(`UPDATE ${table} SET used_at = $2`)) {
        for (const r of collection) if (r.user_id === p[0] && !r.used_at) r.used_at = p[1];
        return rows();
      }
      if (statement.startsWith(`UPDATE ${table} SET used_at=NOW()`)) {
        for (const r of collection) if (r.user_id === p[0] && r[column] === p[1] && !r.used_at) r.used_at = new Date();
        return rows();
      }
      if (statement.startsWith(`UPDATE ${table} SET failed_attempts`)) {
        const r = collection.find((r) => r[id] === p[0]);
        r.failed_attempts++;
        if (r.failed_attempts >= p[1]) r.used_at = p[2];
        return rows();
      }
      if (statement.startsWith(`UPDATE ${table} SET used_at=$2`)) {
        collection.find((r) => r[id] === p[0]).used_at = p[1];
        return rows();
      }
    }
    if (statement.startsWith("INSERT INTO user_sessions")) {
      this.sessions.push({ user_id: p[0], refresh_token_hash: p[1], expires_at: p[4] });
      return rows();
    }
    if (statement.startsWith("DELETE FROM user_sessions WHERE user_id")) {
      this.sessions = this.sessions.filter((s) => s.user_id !== p[0]);
      return rows();
    }
    if (statement.startsWith("DELETE FROM user_sessions WHERE refresh_token_hash")) {
      this.sessions = this.sessions.filter((s) => s.refresh_token_hash !== p[0]);
      return rows();
    }
    if (statement.startsWith("SELECT u.user_id, u.email, u.username, u.is_verified FROM user_sessions")) {
      const session = this.sessions.find((s) => s.refresh_token_hash === p[0] && s.expires_at > new Date());
      return rows(this.users.filter((u) => u.user_id === session?.user_id && u.is_verified));
    }
    throw new Error(`Unmocked SQL: ${statement}`);
  }
}

async function fixture(clock = { value: new Date("2026-11-17T00:00:00.000Z") }) {
  const pool = new MemoryPool();
  const messages = [];
  const handler = createAuthHandler({
    pool,
    mail: async (message) => messages.push(message),
    secret: SECRET,
    now: () => clock.value,
  });
  const server = http.createServer((req, res) => handler(req, res, req.url));
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const url = `http://127.0.0.1:${server.address().port}`;
  const call = async (action, data, cookie) => {
    const response = await fetch(`${url}/api/auth/${action}`, {
      method: data === undefined ? "GET" : "POST",
      headers: { ...(data !== undefined ? { "Content-Type": "application/json" } : {}), ...(cookie ? { Cookie: cookie } : {}) },
      body: data === undefined ? undefined : JSON.stringify(data),
    });
    return { status: response.status, body: await response.json(), cookie: response.headers.get("set-cookie") };
  };
  return { pool, messages, call, close: () => new Promise((resolve) => server.close(resolve)), clock };
}
const emailedCode = (messages) => messages.at(-1).text.match(/\b\d{6}\b/)[0];

test("password hashing and OTP HMAC do not disclose raw credentials", async () => {
  const hash = await hashPassword("Password1");
  assert.match(hash, /^scrypt\$/);
  assert.notEqual(hash.includes("Password1"), true);
  assert.equal(await verifyPassword("Password1", hash), true);
  assert.equal(await verifyPassword("wrongPassword", hash), false);
  const code = newCode();
  assert.match(code, /^\d{6}$/);
  assert.equal(sameHash(codeHash(SECRET, "a", "verify", code), codeHash(SECRET, "a", "verify", code)), true);
  assert.equal(sameHash(codeHash(SECRET, "a", "verify", code), codeHash(SECRET, "a", "reset", code)), false);
});

test("full email verification, password reset and session revocation", async (t) => {
  const f = await fixture();
  t.after(f.close);
  const account = { username: "nhung", email: "nhung@example.com", password: "Password1" };
  assert.equal((await f.call("register", account)).status, 201);
  assert.equal(f.messages.length, 1);
  const verification = emailedCode(f.messages);
  const before = await f.call("login", { username: account.username, password: account.password });
  assert.equal(before.status, 403);
  assert.equal(before.body.code, "EMAIL_NOT_VERIFIED");
  assert.equal((await f.call("verify-email", { email: account.email, code: "xxxxxx" })).status, 400);
  assert.equal((await f.call("verify-email", { email: account.email, code: "000001" === verification ? "000002" : "000001" })).status, 400);
  assert.equal((await f.call("verify-email", { email: account.email, code: verification })).status, 200);
  assert.equal((await f.call("verify-email", { email: account.email, code: verification })).status, 400);
  const login = await f.call("login", { username: account.email, password: account.password });
  assert.equal(login.status, 200);
  assert.match(login.cookie, /HttpOnly; SameSite=Lax/);
  const session = login.cookie.split(";")[0];
  assert.equal((await f.call("me", undefined, session)).status, 200);
  assert.equal((await f.call("forgot-password", { email: account.email })).status, 200);
  const resetCode = emailedCode(f.messages);
  assert.equal((await f.call("reset-password", { email: account.email, code: "000001" === resetCode ? "000002" : "000001", newPassword: "NewPassword1" })).status, 400);
  assert.equal((await f.call("reset-password", { email: account.email, code: resetCode, newPassword: "NewPassword1" })).status, 200);
  assert.equal((await f.call("me", undefined, session)).status, 401);
  assert.equal((await f.call("login", { username: account.username, password: "Password1" })).status, 401);
  assert.equal((await f.call("login", { username: account.username, password: "NewPassword1" })).status, 200);
  assert.equal((await f.call("reset-password", { email: account.email, code: resetCode, newPassword: "AgainPassword1" })).status, 400);
});

test("codes expire and are locked after five bad attempts", async (t) => {
  const f = await fixture(); t.after(f.close);
  const account = { username: "testuser", email: "test@example.com", password: "Password1" };
  await f.call("register", account);
  const first = emailedCode(f.messages);
  const wrong = first === "000001" ? "000002" : "000001";
  for (let i = 0; i < 5; i++)
    assert.equal((await f.call("verify-email", { email: account.email, code: wrong })).status, 400);
  assert.equal((await f.call("verify-email", { email: account.email, code: first })).status, 400);
  f.clock.value = new Date(f.clock.value.getTime() + 61_000);
  assert.equal((await f.call("resend-verification", { email: account.email })).status, 200);
  assert.equal(f.messages.length, 2);
  f.clock.value = new Date(f.clock.value.getTime() + 11 * 60_000);
  assert.equal((await f.call("verify-email", { email: account.email, code: emailedCode(f.messages) })).status, 400);
  assert.equal((await f.call("forgot-password", { email: "missing@example.com" })).status, 200);
});
