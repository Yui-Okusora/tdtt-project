# tdtt-project — PoseXimi v2.1

Frontend PWA nằm trong `PoseXimi_v2.1/`.

**Backend PostgreSQL & email OTP:** xem [BACKEND_SETUP.md](PoseXimi_v2.1/BACKEND_SETUP.md).

Chạy trong thư mục `PoseXimi_v2.1`: `npm install` → cấu hình `.env` từ `.env.example` → `npm run db:migrate` → `npm start`.

Các bảng SQL được tách thành 6 file trong `PoseXimi_v2.1/backend/sql/`.
